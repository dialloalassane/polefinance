"""
tests/test_validators.py
Unit tests for ticker validation and date parsing.
Run with: pytest tests/test_validators.py -v
"""

import pytest
from datetime import date
from brvmpy.utils.validators import validate_ticker, validate_dates
from brvmpy.utils.tickers    import get_ticker_info, VALID_TICKERS


class TestValidateTicker:
    def test_valid_uppercase(self):
        assert validate_ticker("SNTS") == "SNTS"

    def test_valid_lowercase(self):
        assert validate_ticker("snts") == "SNTS"

    def test_valid_mixed(self):
        assert validate_ticker("Snts") == "SNTS"

    def test_invalid_ticker(self):
        with pytest.raises(ValueError, match="not a valid BRVM ticker"):
            validate_ticker("AAPL")

    def test_empty_string(self):
        with pytest.raises(ValueError, match="cannot be empty"):
            validate_ticker("")

    def test_non_string(self):
        with pytest.raises(TypeError):
            validate_ticker(123)

    def test_all_tickers_valid(self):
        for t in VALID_TICKERS:
            assert validate_ticker(t) == t


class TestValidateDates:
    def test_none_returns_none(self):
        s, e = validate_dates(None, None)
        assert s is None and e is None

    def test_string_iso_format(self):
        s, e = validate_dates("2020-01-01", "2023-12-31")
        assert s == date(2020, 1, 1)
        assert e == date(2023, 12, 31)

    def test_slash_format(self):
        s, _ = validate_dates("2020/06/15", None)
        assert s == date(2020, 6, 15)

    def test_date_objects(self):
        d1 = date(2021, 1, 1)
        d2 = date(2022, 1, 1)
        s, e = validate_dates(d1, d2)
        assert s == d1 and e == d2

    def test_start_after_end_raises(self):
        with pytest.raises(ValueError, match="earlier than"):
            validate_dates("2023-12-31", "2020-01-01")

    def test_invalid_format_raises(self):
        with pytest.raises(ValueError, match="Cannot parse"):
            validate_dates("not-a-date", None)


class TestGetTickerInfo:
    def test_returns_dict(self):
        info = get_ticker_info("SNTS")
        assert isinstance(info, dict)
        assert info["ticker"] == "SNTS"
        assert info["cc"] == "sn"
        assert info["sector"] == "Telecom"

    def test_case_insensitive(self):
        assert get_ticker_info("snts")["ticker"] == "SNTS"

    def test_invalid_raises(self):
        with pytest.raises(ValueError):
            get_ticker_info("XYZ999")

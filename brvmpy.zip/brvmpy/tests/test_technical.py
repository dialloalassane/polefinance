"""
tests/test_technical.py
Unit tests for TechnicalAnalysis — fully offline (uses synthetic data).
Run with: pytest tests/test_technical.py -v
"""

import pytest
import numpy as np
import pandas as pd
from brvmpy.analysis.technical import TechnicalAnalysis


def make_df(n: int = 300) -> pd.DataFrame:
    """Generate synthetic OHLCV data."""
    np.random.seed(42)
    close  = 10000 + np.cumsum(np.random.randn(n) * 100)
    high   = close + np.abs(np.random.randn(n) * 50)
    low    = close - np.abs(np.random.randn(n) * 50)
    open_  = close + np.random.randn(n) * 30
    volume = np.abs(np.random.randn(n) * 1000 + 5000)
    idx    = pd.date_range("2020-01-02", periods=n, freq="B")
    return pd.DataFrame(
        {"Open": open_, "High": high, "Low": low, "Close": close, "Volume": volume},
        index=idx,
    )


class TestTechnicalAnalysis:
    def setup_method(self):
        self.df = make_df(300)
        self.ta = TechnicalAnalysis(self.df)

    def test_raises_on_empty(self):
        with pytest.raises(ValueError, match="empty"):
            TechnicalAnalysis(pd.DataFrame())

    def test_raises_on_missing_columns(self):
        with pytest.raises(ValueError, match="missing columns"):
            TechnicalAnalysis(pd.DataFrame({"Close": [1, 2, 3]}))

    def test_compute_all_returns_dataframe(self):
        result = self.ta.compute_all()
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 300

    def test_sma_columns_exist(self):
        result = self.ta.compute_all()
        for col in ["SMA_20", "SMA_50", "SMA_200"]:
            assert col in result.columns

    def test_ema_columns_exist(self):
        result = self.ta.compute_all()
        for col in ["EMA_20", "EMA_50"]:
            assert col in result.columns

    def test_rsi_range(self):
        result = self.ta.compute_all()
        rsi = result["RSI_14"].dropna()
        assert (rsi >= 0).all() and (rsi <= 100).all()

    def test_macd_columns(self):
        result = self.ta.compute_all()
        for col in ["MACD", "MACD_Signal", "MACD_Hist"]:
            assert col in result.columns

    def test_bollinger_ordering(self):
        result = self.ta.compute_all()
        valid = result.dropna(subset=["BB_Upper", "BB_Middle", "BB_Lower"])
        assert (valid["BB_Upper"] >= valid["BB_Middle"]).all()
        assert (valid["BB_Middle"] >= valid["BB_Lower"]).all()

    def test_stochastic_range(self):
        result = self.ta.compute_all()
        sk = result["Stoch_K"].dropna()
        assert (sk >= 0).all() and (sk <= 100).all()

    def test_obv_exists(self):
        result = self.ta.compute_all()
        assert "OBV" in result.columns

    def test_signal_columns(self):
        result = self.ta.compute_all()
        for col in ["Signal_RSI", "Signal_MACD", "Overall_Signal"]:
            assert col in result.columns

    def test_signal_values(self):
        result = self.ta.compute_all()
        valid  = {"BUY", "SELL", "NEUTRAL"}
        assert set(result["Overall_Signal"].dropna().unique()).issubset(valid)

    def test_summary_dict(self):
        summary = self.ta.summary()
        assert isinstance(summary, dict)
        assert "overall_signal" in summary
        assert "rsi_14" in summary
        assert summary["overall_signal"] in {"BUY", "SELL", "NEUTRAL"}

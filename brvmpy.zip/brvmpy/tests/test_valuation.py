"""
tests/test_valuation.py
Unit tests for ValuationEngine — fully offline.
Run with: pytest tests/test_valuation.py -v
"""

import pytest
import math
from brvmpy.analysis.valuation import ValuationEngine


class TestValuationEngine:
    def setup_method(self):
        self.engine = ValuationEngine()

    def test_capm_with_beta(self):
        ke = self.engine.capm(beta=1.0)
        assert ke == pytest.approx(0.06 + 1.0 * 0.07)

    def test_capm_fallback_beta(self):
        ke_none = self.engine.capm(beta=None)
        ke_one  = self.engine.capm(beta=1.0)
        assert ke_none == ke_one

    def test_ddm_basic(self):
        v = self.engine.ddm(dividend=600, beta=0.8)
        assert v is not None and v > 0

    def test_ddm_no_dividend(self):
        assert self.engine.ddm(dividend=0, beta=1.0) is None
        assert self.engine.ddm(dividend=None, beta=1.0) is None

    def test_ddm_negative_dividend(self):
        assert self.engine.ddm(dividend=-100, beta=1.0) is None

    def test_graham_basic(self):
        v = self.engine.graham(eps=1200, book_value=8000)
        expected = round(math.sqrt(22.5 * 1200 * 8000), 0)
        assert v == expected

    def test_graham_zero_eps(self):
        assert self.engine.graham(eps=0, book_value=8000) is None

    def test_graham_negative_book_value(self):
        assert self.engine.graham(eps=500, book_value=-1000) is None

    def test_per_based_telecom(self):
        v = self.engine.per_based(eps=1000, sector="Telecom")
        assert v == 1000 * 15.0

    def test_per_based_unknown_sector(self):
        v = self.engine.per_based(eps=1000, sector="Unknown")
        assert v == 1000 * 10.0  # default PER

    def test_composite_all_values(self):
        v = ValuationEngine.composite([1000, 2000, 3000])
        assert v == 2000.0

    def test_composite_some_none(self):
        v = ValuationEngine.composite([None, 2000, 3000])
        assert v == 2500.0

    def test_composite_all_none(self):
        assert ValuationEngine.composite([None, None]) is None

    def test_margin_of_safety(self):
        mos = ValuationEngine.margin_of_safety(intrinsic=10000, price=7000)
        assert mos == pytest.approx(30.0)

    def test_mos_overvalued(self):
        mos = ValuationEngine.margin_of_safety(intrinsic=8000, price=12000)
        assert mos < 0

    def test_mos_none_price(self):
        assert ValuationEngine.margin_of_safety(10000, None) is None

    def test_verdict_undervalued(self):
        assert self.engine.verdict(35)  == "TRES SOUS-EVALUE"
        assert self.engine.verdict(20)  == "SOUS-EVALUE"
        assert self.engine.verdict(0)   == "JUSTE VALEUR"
        assert self.engine.verdict(-20) == "SUREVALUE"
        assert self.engine.verdict(-40) == "TRES SUREVALUE"
        assert self.engine.verdict(None) == "N/A"

    def test_compute_full(self):
        fund = {
            "price":      15000,
            "eps":        1200,
            "dividend":   600,
            "book_value": 8000,
            "beta":       0.8,
            "per_market": 12.5,
        }
        result = self.engine.compute("SNTS", "Telecom", fund)
        assert result["ticker"] == "SNTS"
        assert result["v_composite"] is not None
        assert result["verdict"] in {
            "TRES SOUS-EVALUE", "SOUS-EVALUE",
            "JUSTE VALEUR", "SUREVALUE", "TRES SUREVALUE"
        }
        assert "DDM" in result["methods_used"]
        assert "Graham" in result["methods_used"]
        assert "PER" in result["methods_used"]

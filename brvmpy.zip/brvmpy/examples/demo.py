"""
examples/demo.py
================
Complete demonstration of brvmpy library.
Run: python examples/demo.py
"""

from brvmpy import BRVM

brvm = BRVM()

print("=" * 60)
print("  brvmpy — BRVM Financial Data Library Demo")
print("=" * 60)

# ── 1. List all tickers ───────────────────────────────────────────
print("\n[1] All BRVM tickers:")
tickers = brvm.tickers()
print(tickers.to_string(index=False))

# ── 2. Historical prices ──────────────────────────────────────────
print("\n[2] Historical prices for SNTS (2022-2024):")
df = brvm.history("SNTS", start="2022-01-01", end="2024-12-31")
print(df.tail(5))
print(f"    Total rows: {len(df)}")

# ── 3. Technical analysis ─────────────────────────────────────────
print("\n[3] Technical analysis for SNTS:")
ta = brvm.technical("SNTS", start="2023-01-01")
print(ta[["Close", "SMA_50", "RSI_14", "MACD", "Overall_Signal"]].tail(5))

# ── 4. Fundamental data ───────────────────────────────────────────
print("\n[4] Fundamentals for SNTS:")
fund = brvm.fundamentals("SNTS")
for k, v in fund.items():
    if k != "source_url":
        print(f"    {k:<20}: {v}")

# ── 5. Intrinsic value ────────────────────────────────────────────
print("\n[5] Intrinsic value for SNTS:")
iv = brvm.intrinsic_value("SNTS")
print(f"    Price      : {iv['price']:>10,.0f} FCFA")
print(f"    DDM Value  : {str(iv['v_ddm']):>10} FCFA")
print(f"    Graham     : {str(iv['v_graham']):>10} FCFA")
print(f"    PER Value  : {str(iv['v_per']):>10} FCFA")
print(f"    Composite  : {str(iv['v_composite']):>10} FCFA")
print(f"    Margin/Safety: {str(iv['margin_of_safety']):>8}%")
print(f"    Verdict    : {iv['verdict']}")

# ── 6. Screen for opportunities ───────────────────────────────────
print("\n[6] Screening for undervalued stocks (MoS >= 15%):")
df_screen = brvm.screen(min_mos=15)
print(df_screen[["ticker", "price", "v_composite", "margin_of_safety", "verdict"]])

print("\nDone!")

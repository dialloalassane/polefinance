"""
brvmpy — BRVM Financial Data Library
=====================================
Historical data, fundamental analysis, and technical analysis
for all companies listed on the Bourse Régionale des Valeurs Mobilières (BRVM).

Data source: richbourse.com / sikafinance.com
Exchange: BRVM (West African Regional Stock Exchange)
Currency: FCFA (XOF)

Quick start
-----------
>>> from brvmpy import BRVM
>>> brvm = BRVM()
>>> df = brvm.history("SNTS", start="2020-01-01", end="2024-12-31")
>>> fa  = brvm.fundamentals("SNTS")
>>> ta  = brvm.technical("SNTS")

>>> # Get all tickers
>>> tickers = brvm.tickers()

>>> # Intrinsic value
>>> iv = brvm.intrinsic_value("SNTS")
"""

from brvmpy.client import BRVM
from brvmpy.data.historical import HistoricalData
from brvmpy.data.fundamentals import FundamentalData
from brvmpy.analysis.technical import TechnicalAnalysis
from brvmpy.analysis.valuation import ValuationEngine
from brvmpy.utils.tickers import TICKERS

__version__ = "1.0.0"
__author__  = "PoleFinance"
__license__ = "MIT"

__all__ = [
    "BRVM",
    "HistoricalData",
    "FundamentalData",
    "TechnicalAnalysis",
    "ValuationEngine",
    "TICKERS",
]

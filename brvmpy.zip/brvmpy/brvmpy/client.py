"""
brvmpy.client
=============
Main entry point for the brvmpy library.
Provides a unified interface to all data and analysis modules.
"""

from __future__ import annotations
import pandas as pd
from datetime import date, datetime
from typing import Optional, Union

from brvmpy.data.historical   import HistoricalData
from brvmpy.data.fundamentals import FundamentalData
from brvmpy.analysis.technical  import TechnicalAnalysis
from brvmpy.analysis.valuation  import ValuationEngine
from brvmpy.utils.tickers       import TICKERS, get_ticker_info
from brvmpy.utils.validators    import validate_ticker, validate_dates


class BRVM:
    """
    Main BRVM client.

    Parameters
    ----------
    delay : float
        Seconds to wait between HTTP requests (default 1.2).
        Increase if you encounter rate-limiting.
    timeout : int
        HTTP request timeout in seconds (default 25).

    Examples
    --------
    >>> from brvmpy import BRVM
    >>> brvm = BRVM()

    >>> # Historical prices
    >>> df = brvm.history("SNTS", start="2020-01-01", end="2024-12-31")

    >>> # Fundamental data
    >>> fa = brvm.fundamentals("SNTS")

    >>> # Technical indicators
    >>> ta = brvm.technical("SNTS", start="2023-01-01")

    >>> # Intrinsic value (multi-method)
    >>> iv = brvm.intrinsic_value("SNTS")

    >>> # Full report for one ticker
    >>> report = brvm.full_report("SNTS")

    >>> # Screen all tickers by criterion
    >>> undervalued = brvm.screen(min_mos=15)
    """

    def __init__(self, delay: float = 1.2, timeout: int = 25):
        self._delay   = delay
        self._timeout = timeout
        self._hist    = HistoricalData(delay=delay, timeout=timeout)
        self._fund    = FundamentalData(delay=delay, timeout=timeout)
        self._val     = ValuationEngine()

    # ── Tickers ──────────────────────────────────────────────────────────────

    def tickers(self) -> pd.DataFrame:
        """Return a DataFrame of all BRVM-listed tickers with metadata."""
        return pd.DataFrame(TICKERS, columns=["ticker", "name", "sector", "country", "cc"])

    def ticker_info(self, ticker: str) -> dict:
        """Return metadata for a single ticker."""
        return get_ticker_info(validate_ticker(ticker))

    # ── Historical data ───────────────────────────────────────────────────────

    def history(
        self,
        ticker: str,
        start: Optional[Union[str, date]] = None,
        end:   Optional[Union[str, date]] = None,
    ) -> pd.DataFrame:
        """
        Fetch daily OHLCV historical prices.

        Parameters
        ----------
        ticker : str
            BRVM ticker symbol (e.g. "SNTS", "ETIT", "SGBC").
        start : str or date, optional
            Start date in "YYYY-MM-DD" format. Defaults to earliest available.
        end : str or date, optional
            End date in "YYYY-MM-DD" format. Defaults to today.

        Returns
        -------
        pd.DataFrame
            Columns: Date, Open, High, Low, Close, Volume
            Index: DatetimeIndex

        Source
        ------
        richbourse.com — same API as the CRAN BRVM R package
        (https://github.com/cran/BRVM/blob/master/R/brvm-get.R)
        """
        ticker = validate_ticker(ticker)
        start, end = validate_dates(start, end)
        return self._hist.fetch(ticker, start=start, end=end)

    def history_all(
        self,
        start: Optional[Union[str, date]] = None,
        end:   Optional[Union[str, date]] = None,
        verbose: bool = True,
    ) -> dict[str, pd.DataFrame]:
        """
        Fetch historical prices for ALL BRVM tickers.

        Returns
        -------
        dict[str, pd.DataFrame]
            Keys are ticker symbols; values are OHLCV DataFrames.
        """
        start, end = validate_dates(start, end)
        return self._hist.fetch_all(start=start, end=end, verbose=verbose)

    # ── Fundamental data ──────────────────────────────────────────────────────

    def fundamentals(self, ticker: str) -> dict:
        """
        Fetch fundamental data for a ticker.

        Returns
        -------
        dict
            Keys: price, eps, dividend, book_value, beta, per,
                  div_yield, rsi, market_cap, shares, source_url

        Source
        ------
        sikafinance.com — same source as CRAN BRVM R package BRVM_company_info()
        """
        ticker = validate_ticker(ticker)
        info   = get_ticker_info(ticker)
        return self._fund.fetch(ticker, cc=info["cc"])

    def fundamentals_all(self, verbose: bool = True) -> pd.DataFrame:
        """
        Fetch fundamentals for ALL BRVM tickers.

        Returns
        -------
        pd.DataFrame
            One row per ticker with all fundamental fields.
        """
        return self._fund.fetch_all(verbose=verbose)

    # ── Technical analysis ────────────────────────────────────────────────────

    def technical(
        self,
        ticker: str,
        start: Optional[Union[str, date]] = None,
        end:   Optional[Union[str, date]] = None,
    ) -> pd.DataFrame:
        """
        Compute technical indicators on historical price data.

        Indicators computed
        -------------------
        Trend     : SMA_20, SMA_50, SMA_200, EMA_20, EMA_50
        Momentum  : RSI_14, MACD, MACD_signal, MACD_hist
        Volatility: BB_upper, BB_middle, BB_lower, ATR_14
        Volume    : OBV, Volume_SMA_20
        Other     : Stochastic_%K, Stochastic_%D, Williams_%R

        Returns
        -------
        pd.DataFrame
            Original OHLCV + all indicators, indexed by Date.
        """
        ticker = validate_ticker(ticker)
        start, end = validate_dates(start, end)
        df = self._hist.fetch(ticker, start=start, end=end)
        return TechnicalAnalysis(df).compute_all()

    # ── Valuation ─────────────────────────────────────────────────────────────

    def intrinsic_value(self, ticker: str) -> dict:
        """
        Compute intrinsic value using multiple methods.

        Methods
        -------
        - DDM (Gordon Growth Model)   : V = D1 / (Ke - g)
        - Graham Number               : V = sqrt(22.5 × EPS × Book Value)
        - PER-based                   : V = EPS × Sector PER
        - Composite                   : Average of available methods

        Market parameters
        -----------------
        - Rf  = 6.0%  (BOAD/UEMOA 10-year bond)
        - ERP = 7.0%  (BRVM historical equity risk premium)
        - g   = 3.0%  (conservative perpetual growth)

        Returns
        -------
        dict
            Keys: ticker, price, fundamentals, ke, v_ddm, v_graham,
                  v_per, v_composite, margin_of_safety, verdict
        """
        ticker = validate_ticker(ticker)
        info   = get_ticker_info(ticker)
        fund   = self._fund.fetch(ticker, cc=info["cc"])
        return self._val.compute(ticker, info["sector"], fund)

    def intrinsic_value_all(self, verbose: bool = True) -> pd.DataFrame:
        """
        Compute intrinsic value for ALL BRVM tickers.

        Returns
        -------
        pd.DataFrame
            Sorted by margin of safety (best opportunities first).
        """
        df_fund = self._fund.fetch_all(verbose=verbose)
        rows = []
        for _, row in df_fund.iterrows():
            fund = row.to_dict()
            info = get_ticker_info(row["ticker"])
            iv   = self._val.compute(row["ticker"], info["sector"], fund)
            rows.append(iv)
        df = pd.DataFrame(rows)
        return df.sort_values("margin_of_safety", ascending=False, na_position="last")

    # ── Full report ───────────────────────────────────────────────────────────

    def full_report(
        self,
        ticker: str,
        start: Optional[Union[str, date]] = None,
        end:   Optional[Union[str, date]] = None,
    ) -> dict:
        """
        Generate a comprehensive report combining price history,
        technical analysis, fundamental data, and intrinsic value.

        Returns
        -------
        dict with keys:
            - info         : ticker metadata
            - history      : OHLCV DataFrame
            - technical    : OHLCV + indicators DataFrame
            - fundamentals : fundamental dict
            - valuation    : intrinsic value dict
        """
        ticker = validate_ticker(ticker)
        info   = get_ticker_info(ticker)
        start, end = validate_dates(start, end)

        hist  = self._hist.fetch(ticker, start=start, end=end)
        ta    = TechnicalAnalysis(hist).compute_all()
        fund  = self._fund.fetch(ticker, cc=info["cc"])
        val   = self._val.compute(ticker, info["sector"], fund)

        return {
            "info":         info,
            "history":      hist,
            "technical":    ta,
            "fundamentals": fund,
            "valuation":    val,
        }

    # ── Screening ─────────────────────────────────────────────────────────────

    def screen(
        self,
        min_mos:    Optional[float] = None,
        max_per:    Optional[float] = None,
        min_div:    Optional[float] = None,
        sectors:    Optional[list]  = None,
        verbose:    bool = True,
    ) -> pd.DataFrame:
        """
        Screen all BRVM stocks by multiple criteria.

        Parameters
        ----------
        min_mos : float, optional
            Minimum margin of safety (%). E.g. 15 for >= 15%.
        max_per : float, optional
            Maximum Price-to-Earnings ratio.
        min_div : float, optional
            Minimum dividend yield (%).
        sectors : list of str, optional
            Filter by sector(s).
        verbose : bool
            Print progress (default True).

        Returns
        -------
        pd.DataFrame
            Filtered and sorted results.
        """
        df = self.intrinsic_value_all(verbose=verbose)

        if min_mos is not None:
            df = df[df["margin_of_safety"] >= min_mos]
        if max_per is not None:
            df = df[df["per_market"].notna() & (df["per_market"] <= max_per)]
        if min_div is not None:
            df = df[df["div_yield"].notna() & (df["div_yield"] >= min_div)]
        if sectors:
            sectors_upper = [s.upper() for s in sectors]
            df = df[df["sector"].str.upper().isin(sectors_upper)]

        return df.reset_index(drop=True)

    def __repr__(self) -> str:
        return f"BRVM(tickers={len(TICKERS)}, delay={self._delay}s)"
